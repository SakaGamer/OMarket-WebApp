<?php

   $vb = "abcd";
   var_dump($vb);
   echo strlen($vb);
 ?>

<html>
<head>
    
    </head>


</html>