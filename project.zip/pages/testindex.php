<?php 

//    require_once "header.php";

?>

<link rel="stylesheet" href="../css/bootstrap.min.css">


<nav class="navbar navbar-expand navbar-light bg-light justify-content-between">
    <div class="container p-1">
     <a class="navbar-brand text-uppercase"><h3>Online Market</h3></a>
  
<!--  <div class="collapse navbar-collapse">-->
        <ul class="navbar-nav">
      <li class="nav-item mx-3">
          <a href="#" class="nav-link">Home</a>
      </li>
      <li class="nav-item mx-3">
          <a href="#" class="nav-link">Sell</a>
      </li>
      <li class="nav-item mx-3">
          <a href="#" class="nav-link">My Product</a>
      </li>
      <li class="nav-item mx-3">
          <a href="#" class="nav-link">Location</a>
      </li>
      <li class="nav-item mx-3">
          <a href="#" class="nav-link">About</a>
      </li>
      <li class="nav-item mx-3">
          <a href="#" class="nav-link">Profile</a>
      </li>
  </ul>      
<!--  </div>-->
  
  
<!--
  <div>
  <span class="navbar-text mx-2">
    <a href="#" class="nav-link">Home</a>
    </span>
  <span class="navbar-text mx-2">
    <a href="#" class="nav-link">Sell</a>
    </span>
    <span class="navbar-text mx-2">
    <a href="#" class="nav-link">My Product</a>
    </span>
  <span class="navbar-text mx-2">
    <a href="#" class="nav-link">Location</a>
    </span>
  <span class="navbar-text mx-2">
    <a href="#" class="nav-link">Aboout</a>
    </span>
  <span class="navbar-text mx-2">
    <a href="#" class="nav-link">Profile</a>
    </span>
        </div>
-->
        
</div>
</nav>


<div class="container">
   <div class="col-8 mx-auto">
<!--       <div class="container">-->
          
           <div class="media my-4">
        <img src="../fileUploads/workplace.jpg" class="d-flex mr-3" width="100" height="100">
        <div class="media-body">
        <h5 class="mt-0">Hello this is title</h5>
        lorem ipsom dur leoo faslfjks jfskfas ;jjf;lj jlks fsdfj sjf 
        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
    </div>
    </div>
    
    
    <div class="media my-4">
  <img class="d-flex mr-3" src="../fileUploads/workplace.jpg" width="100" height="100">
  <div class="media-body">
    <h5 class="mt-0">Media heading</h5>
    Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
    Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
  </div>
</div>
<!--       </div>-->
  
      <div class="fb-share-button" data-href="https://developers.facebook.com/docs/plugins/" data-layout="button" data-size="large" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&amp;src=sdkpreparse">Share</a></div>
   </div>
</div>